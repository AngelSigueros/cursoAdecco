
let name1 = "";
let number1 = 50;
let number2 = 10;

let number3 = 20;


if(50 < 10){
    console.log("Verdadero") // Solo cuando la condición es verdadera
} else{
    console.log("Falso") // Solo cuando la condición es falsa
}

// siempre
// console.log("Falso") 
console.log("Continuación 1")
// console.log("Continuación 2")