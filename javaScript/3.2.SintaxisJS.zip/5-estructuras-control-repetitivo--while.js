



// while
// var cont = 20;
// while (20 < 10) { // 10 < 10 ya no se cumple la condición y salimos del bucle
//     console.log("Iteración while valor cont: " + cont);
//     cont++; // Incremento
// }

// // do while
var cont2 = 1;
do {
    console.log("Iteración while valor cont2: " + cont2);
    cont2++;
}
while (cont2 < 10);

console.log("continuacion");