
console.log("Hola desde script holamundo.js");


let hola = "que tal";