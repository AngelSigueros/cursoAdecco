/*
 Archivo JavaScript para representar el uso de scripts externos en 
 el código HTML.
 author: La NASA.
 year: 2021
 license: MIT.
*/

// Creación variable
var variable = 5;
// Imprimir por consola
console.log(variable);
alert("Bonjour");
console.log("Texto creado desde JavaScript!");