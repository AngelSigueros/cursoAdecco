

// estructura de control iterativa for
for (let i = 0; i < 10; i++) {
    if (i === 5) {
        break; // hace salirse del bucle
    }
    console.log("El valor de i es: " + i)
}
console.log("resto del programa")

