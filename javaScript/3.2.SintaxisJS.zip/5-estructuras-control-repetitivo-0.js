
//            0         1       2
// 1 2 3 4 5  aquí también tengo 5 elementos
for (i = 50; i > 1; i--) {
    // 1 iteracion  i = 0
    // 2 iteracion  i = 1
    // 3 iteracion  i = 2
    // 4 iteracion  i = 3
    // 5 iteracion  i = 4
    // 6 iteracion  i = 5, Esta iteración no se ejecuta porque 5 < 5 no se cumple
    console.log("El valor de i es: " + (i));
}


let check = true;

while(true){

    console.log("Selecciona una opción");

    if(option == "Editar"){

    } else if (option == "Borrar"){

    }else if(option == "Salir"){
        break;
    }

    // ... 

    // ...

     if(true){
        check = false
    }
}