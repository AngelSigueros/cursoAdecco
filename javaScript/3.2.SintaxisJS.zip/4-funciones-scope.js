


// variables globales
let hola = "Mundo";

// funciones

// lógica de negocio (nuestro código)

// funciones

let apellido = "Alan"; // global

printName();
console.log(apellido);
// console.log(age);


function printName(){
    let age = 99; // local
    // console.log(apellido);
    console.log(age);
}