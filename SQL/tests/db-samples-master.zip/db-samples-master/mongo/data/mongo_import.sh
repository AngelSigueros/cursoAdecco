mongoimport -d northwind -c category --drop --jsonArray --file  category.json 
  
mongoimport -d northwind -c customer --drop --jsonArray --file  customer.json 
 
mongoimport -d northwind -c employee --drop --jsonArray --file  employee.json 
 
mongoimport -d northwind -c employeeTerritory --drop --jsonArray --file  employeeTerritory.json 
 
mongoimport -d northwind -c orderDetail --drop --jsonArray --file  orderDetail.json 
 
mongoimport -d northwind -c product --drop --jsonArray --file  product.json 
 
mongoimport -d northwind -c region --drop --jsonArray --file  region.json 
 
mongoimport -d northwind -c salesOrder --drop --jsonArray --file  salesOrder.json 
 
mongoimport -d northwind -c shipper --drop --jsonArray --file  shipper.json 
 
mongoimport -d northwind -c supplier --drop --jsonArray --file  supplier.json 
 
mongoimport -d northwind -c territory --drop --jsonArray --file  territory.json 
  
 